ALTER TABLE `t_email_queue` ADD `isdelete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未删除,1已删除';
